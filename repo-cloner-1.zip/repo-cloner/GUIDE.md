# Repo Cloner: Guide

This guide explains how to use the web page and the Termux script, how the tutorials work, and how the project is organized. For a short overview, see [README.md](README.md).

## Running it

**Web page:** open `index.html` in a browser. Keep the whole folder together, because the page loads its styles and scripts from the `css` and `js` folders. On Android, extract the zip first, then open `index.html` with Chrome.

If a browser blocks local files, serve the folder instead:

```
cd repo-cloner
python -m http.server 8000
```

Then visit `http://localhost:8000`.

**Termux:**

```
pkg install python git
python repo_cloner.py clone owner/repo
```

## Tokens

A token is only needed for private repos, for the copy feature, and to avoid GitHub's limit of 60 requests an hour without one.

1. On GitHub, go to Settings, Developer settings, Personal access tokens.
2. Create a token. A classic token with the `repo` scope is the simplest. A fine-grained token needs read access to contents (source) or permission to create repositories and write contents (destination).
3. Paste it in the page's token box, or pass it to the script with `--token` or the `GITHUB_TOKEN` environment variable. The copy destination uses `--dest-token` or `DEST_TOKEN`.

The web page sends tokens only to GitHub and does not store them. Treat tokens like passwords and delete them when you are done.

## The web page

### Tabs

- **Download files:** fetches each file, shows progress per file and overall, then packs everything into a zip.
- **Quick zip:** downloads GitHub's own zip in one go. It cannot filter. If the browser blocks the direct download, it falls back to GitHub's zip link, which works for public repos only.
- **Copy to account:** creates a new repo on your account and copies the files in as one commit per branch. It does not copy history. Use the script for that.

### Choosing branches and files

Tap **Choose branches and files** (on the Download files and Copy tabs). It is optional. Without it you get the default branch and every file.

- **Branches:** tick one, several, or **Select all**.
- **Patterns:** type one per line. Anything that matches is included.
- **Tick files:** pick from the list, and use the filter box to find them. The list shows files from one branch, but ticks apply to every selected branch.
- Patterns and ticks add together. If you use neither, you get all files.
- With several branches, the zip has one folder per branch.

### Pattern cheat sheet

| Pattern | Matches |
|---|---|
| `README.md` | That name at any depth |
| `*.md` | Every Markdown file at any depth |
| `docs/` | Everything inside the docs folder |
| `src/*.py` | Python files directly in src |
| `src/**/*.py` | Python files anywhere under src |

### Timeline

The step list shows each stage (connect, read, download, package or write, finished) with its time. Two bars show the current file and overall progress. A status line below shows errors and the final result, such as the saved zip name or the link to your new repo.

## Tutorials

Tap **Help** at the top right and choose a style:

- **Spotlight tour:** dims the page and highlights each part in turn with a short tip. It uses example branches, files, and a sample timeline, then restores the page when you finish.
- **Auto-playing demo:** a pretend repo is downloaded on its own, with captions and a Replay button.
- **Welcome slides:** four short animated cards. Swipe or tap Next.

All three cover the basics, choosing branches and files, tokens and private repos, and reading the timeline. Tutorials only open when you tap Help, and they are disabled while a download is running. Animations switch off if your device is set to reduce motion.

## The Termux script

| Command | What it does |
|---|---|
| `clone URL` | Downloads files and full history using git |
| `zip URL` | Downloads a zip, optionally filtered |
| `copy URL --dest-token T` | Copies to your account with history, branches, and optionally tags |
| `branches URL` | Lists branches (`*` marks the default) |
| `tree URL` | Lists files on a branch, so you can test patterns first |

Options: `-b BRANCH` (repeatable), `--all-branches`, `-f PATTERN` (repeatable), `--dir`, `--out`, `--name`, `--private`, `--tags`.

### Examples

```
python repo_cloner.py branches owner/repo
python repo_cloner.py tree owner/repo -f "src/**/*.py"
python repo_cloner.py clone owner/repo -b main -b dev
python repo_cloner.py clone owner/repo -f docs/ -f README.md
python repo_cloner.py zip owner/repo --all-branches -f "*.md"
python repo_cloner.py copy owner/repo --dest-token TOKEN --private -b main
```

### Notes

- **Several branches in `clone`:** the first `-b` is checked out and the others are fetched as local branches.
- **File filters in `clone`:** uses git's sparse checkout with partial clone, so only matching files are downloaded, with full history kept. Needs git 2.35 or newer. Patterns follow git's rules, which match the cheat sheet for common cases.
- **File filters in `zip`:** the whole archive is downloaded, then only matching files are kept.
- **`copy` cannot filter files,** because it keeps full history. For a file-filtered copy, use the web page.
- **`copy` branches:** with no `-b`, it copies all branches and tags. With `-b`, only those branches are copied, plus tags if you add `--tags`.

## How the project is organized

| Path | Purpose |
|---|---|
| `index.html` | Page markup only |
| `css/styles.css` | Page styles, including dark mode |
| `css/tutorial.css` | Styles for the chooser, tour, demo, and slides |
| `js/app.js` | All app logic, plus a small `RC` object the tutorials use to show example content |
| `js/tutorial.js` | Opens the chooser when you tap Help |
| `js/tutorial-tour.js`, `tutorial-demo.js`, `tutorial-slides.js` | One file per tutorial style. Each registers itself on `window.Tutorials` and builds its own markup the first time it opens |
| `js/vendor/` | JSZip, included so the page works offline |

The scripts are plain classic scripts rather than ES modules, because browsers block modules on `file://` pages. To add a new tutorial style, create `js/tutorial-yourname.js` that sets `Tutorials.yourname = { title, text, start() }`, add it to the `ORDER` list in `tutorial.js`, and add its script tag to `index.html`.

## Limits and troubleshooting

- **"rate limit? add a token":** GitHub allows 60 requests an hour without a token. Add one.
- **"private repo? add a token":** a 404 on a repo you know exists usually means it is private.
- **Very large repos:** GitHub may cut off the file list. The page warns you when that happens. Use the script's `clone` for those.
- **Submodules** are skipped by the web page.
- **Copy fails on `.github/workflows` files:** your token needs the `workflow` scope.
- **"Nothing matched":** check your patterns with `tree` in the script, or tick files from the list in the page.
- **Help does nothing:** tutorials are disabled while a download is running. Wait for it to finish.

## What has been tested

Tested: every script's syntax, the Help button and chooser, all three tutorials (steps, cleanup, replay, close), file references in `index.html`, and the Python script's pattern matching, branch and file listing, sparse clone with several branches, zip filtering, and error handling (with GitHub's API simulated because of rate limits). Not tested: the page in a real phone browser, and the `copy` features, which need two accounts and tokens.
