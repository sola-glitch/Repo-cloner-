#!/usr/bin/env python3
"""Repo Cloner for Termux (standard library only; git needed for clone and copy).

  repo_cloner.py clone    URL [-b BRANCH]... [--all-branches] [-f PATTERN]... [--dir NAME]
  repo_cloner.py zip      URL [-b BRANCH]... [--all-branches] [-f PATTERN]... [--out FILE]
  repo_cloner.py copy     URL --dest-token T [-b BRANCH]... [--all-branches] [--tags] [--name NEW] [--private]
  repo_cloner.py branches URL
  repo_cloner.py tree     URL [-b BRANCH] [-f PATTERN]...

-b and -f can be repeated. Tokens: --token / GITHUB_TOKEN (private source),
--dest-token / DEST_TOKEN (account that receives the copy). See the guide for details.
"""
import argparse, base64, json, os, re, shutil, subprocess, sys, tempfile, time, zipfile
import urllib.error, urllib.parse, urllib.request

T0 = time.time()
ts = lambda: time.strftime('%H:%M:%S')


def log(m):
    print(f'\r{" "*70}\r[{ts()}] {m}', flush=True)


def die(m):
    print(f'\n✗ {m}', flush=True)
    sys.exit(1)


def fmt(n):
    return f'{n} B' if n < 1024 else f'{n/1024:.1f} KB' if n < 1048576 else f'{n/1048576:.1f} MB'


def bar(frac, label=''):
    n = int(max(0, min(1, frac)) * 24)
    sys.stdout.write(f'\r  [{"█"*n}{"░"*(24-n)}] {frac*100:3.0f}% {label[:28]:<28}')
    sys.stdout.flush()


class Timeline:
    def __init__(self, names):
        self.names, self.i, self.t = names, -1, time.time()

    def go(self, i):
        self.done()
        self.i, self.t = i, time.time()
        print(f'\n[{ts()}] ▸ {self.names[i]}  (step {i+1} of {len(self.names)})', flush=True)

    def done(self):
        if self.i >= 0:
            print(f'\r{" "*70}\r[{ts()}] ✓ {self.names[self.i]}  {time.time()-self.t:.1f}s', flush=True)

    def finish(self):
        self.done()
        print(f'\nAll done in {time.time()-T0:.1f}s')


def parse(s):
    s = re.sub(r'\.git$', '', s.strip())
    m = re.search(r'github\.com[/:]([^/]+)/([^/#?]+)(?:/tree/([^#?]+))?', s) or re.match(r'^([\w.-]+)/([\w.-]+)$', s)
    if not m:
        die('Enter a GitHub URL or owner/repo.')
    return m.group(1), re.sub(r'\.git$', '', m.group(2)), (m.group(3) if m.re.groups > 2 else None)


def rx(p):
    """File pattern to regex: * inside a folder, ** across folders, folder name = everything inside,
    a name without a slash matches at any depth."""
    p = re.sub(r'^\.?/', '', p.strip())
    if not p:
        return None
    anywhere = '/' not in p
    if p.endswith('/'):
        p += '**'
    r, i = '', 0
    while i < len(p):
        c = p[i]
        if c == '*' and p[i+1:i+2] == '*':
            if p[i+2:i+3] == '/':
                r, i = r + '(?:.*/)?', i + 3
            else:
                r, i = r + '.*', i + 2
        elif c == '*':
            r, i = r + '[^/]*', i + 1
        elif c == '?':
            r, i = r + '[^/]', i + 1
        else:
            r, i = r + re.escape(c), i + 1
    wild = bool(re.search(r'[*?]', p))
    return re.compile('^' + ('(?:.*/)?' if anywhere else '') + r + ('' if wild else '(?:/.*)?') + '$')


def patterns(a):
    return [x for x in (rx(f) for f in (a.files or [])) if x]


def api(path, token=None, data=None, method=None):
    url = path if path.startswith('http') else 'https://api.github.com' + path
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None, method=method)
    req.add_header('Accept', 'application/vnd.github+json')
    req.add_header('User-Agent', 'repo-cloner')
    if token:
        req.add_header('Authorization', 'Bearer ' + token)
    if data is not None:
        req.add_header('Content-Type', 'application/json')
    try:
        return urllib.request.urlopen(req)
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read()).get('message', e.reason)
        except Exception:
            msg = e.reason
        hint = ' (private repo? add a token)' if e.code == 404 and not token else ''
        hint = ' (rate limit? add a token)' if e.code in (403, 429) else hint
        die(f'GitHub said {e.code}: {msg}{hint}')
    except urllib.error.URLError as e:
        die(f'Network problem: {e.reason}')


def repo_info(o, r, token):
    return json.load(api(f'/repos/{o}/{r}', token))


def list_branches(o, r, token):
    out = []
    for pg in range(1, 11):
        page = json.load(api(f'/repos/{o}/{r}/branches?per_page=100&page={pg}', token))
        out += [b['name'] for b in page]
        if len(page) < 100:
            break
    return out


def pick(a, o, r, url_branch, info, default):
    """Branches to use: --all-branches, else every -b, else the link's branch, else `default`."""
    names = list_branches(o, r, a.token)
    if getattr(a, 'all_branches', False):
        return names
    want = a.branch or ([url_branch] if url_branch else [])
    for b in want:
        if b not in names:
            die(f'Branch "{b}" not found. Branches: ' + ', '.join(names[:20]) + (' ...' if len(names) > 20 else ''))
    return want or default


def git(args, token=None, soft=False):
    pre = []
    if token:
        cred = base64.b64encode(f'x-access-token:{token}'.encode()).decode()
        pre = ['-c', f'http.extraHeader=Authorization: Basic {cred}']
    try:
        p = subprocess.Popen(['git'] + pre + args, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL)
    except FileNotFoundError:
        die('git is not installed. Run: pkg install git')
    buf, tail = b'', []
    while True:
        c = p.stderr.read(1)
        if not c:
            break
        if c in (b'\r', b'\n'):
            line, buf = buf.decode(errors='ignore').strip(), b''
            m = re.search(r'(\d+)%', line)
            if m:
                bar(int(m.group(1)) / 100, line.split(':')[0])
            elif line:
                tail.append(line)
        else:
            buf += c
    if p.wait():
        if soft:
            return False
        die('git failed: ' + ' | '.join(tail[-2:]))
    return True


def cmd_branches(a):
    o, r, _ = parse(a.url)
    info = repo_info(o, r, a.token)
    for b in list_branches(o, r, a.token):
        print(('* ' if b == info['default_branch'] else '  ') + b)
    print('\n* = default branch')


def cmd_tree(a):
    o, r, ub = parse(a.url)
    info = repo_info(o, r, a.token)
    b = (a.branch or [ub or info['default_branch']])[0]
    t = json.load(api(f'/repos/{o}/{r}/git/trees/{urllib.parse.quote(b, safe="")}?recursive=1', a.token))
    pats = patterns(a)
    files = [x['path'] for x in t['tree'] if x['type'] == 'blob' and (not pats or any(p.match(x['path']) for p in pats))]
    print('\n'.join(files))
    print(f'\n{len(files)} files on {b}' + (' (list cut short by GitHub)' if t.get('truncated') else ''))


def cmd_clone(a):
    o, r, ub = parse(a.url)
    tl = Timeline(['Connect to GitHub', 'Clone files and history', 'Finished'])
    tl.go(0)
    info = repo_info(o, r, a.token)
    log(f'Found {info["full_name"]} (about {fmt(info["size"]*1024)}, default branch {info["default_branch"]})')
    brs = pick(a, o, r, ub, info, [])
    if brs and not a.all_branches:
        log('Branches: ' + ', '.join(brs))
    tl.go(1)
    dest, url, d = a.dir or r, f'https://github.com/{o}/{r}.git', None
    d = ['-C', dest]
    args = ['clone', '--progress']
    if a.files:
        args += ['--filter=blob:none', '--no-checkout']
    if brs and not a.all_branches:
        args += ['--single-branch', '--branch', brs[0]]
    git(args + [url, dest], a.token)
    if brs and not a.all_branches and len(brs) > 1:
        git(d + ['remote', 'set-branches', '--add', 'origin'] + brs[1:])
        git(d + ['fetch', '--progress', 'origin'], a.token)
    for b in (brs if a.all_branches else brs[1:]):
        git(d + ['branch', '--track', b, 'origin/' + b], soft=True)
    if a.files:
        git(d + ['sparse-checkout', 'set', '--no-cone'] + a.files)
        git(d + ['checkout'], a.token)
    log(f'Saved to {os.path.abspath(dest)}')
    tl.finish()


def download(url, token, path):
    resp = api(url, token)
    total = int(resp.headers.get('Content-Length') or 0)
    got = 0
    with open(path, 'wb') as f:
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            f.write(chunk)
            got += len(chunk)
            bar(got / total if total else 0, fmt(got) + (f' / {fmt(total)}' if total else ''))
    return got


def cmd_zip(a):
    o, r, ub = parse(a.url)
    tl = Timeline(['Connect to GitHub', 'Download zip', 'Finished'])
    tl.go(0)
    info = repo_info(o, r, a.token)
    brs = pick(a, o, r, ub, info, [info['default_branch']])
    pats = patterns(a)
    log('Branches: ' + ', '.join(brs) + (f' | {len(pats)} file pattern(s)' if pats else ''))
    tl.go(1)
    tmp, parts = tempfile.mkdtemp(prefix='cloner-'), []
    multi = len(brs) > 1
    try:
        for i, b in enumerate(brs):
            if multi:
                print(f'\r{" "*70}\r[{ts()}]   {b} ({i+1} of {len(brs)})', flush=True)
            path = os.path.join(tmp, f'{i}.zip')
            download(f'/repos/{o}/{r}/zipball/{urllib.parse.quote(b, safe="")}', a.token, path)
            parts.append((b, path))
        out = a.out or (f'{r}-branches.zip' if multi else f'{r}-{brs[0].replace("/", "-")}.zip')
        if not multi and not pats:
            shutil.move(parts[0][1], out)
        else:
            kept = 0
            with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zo:
                for b, path in parts:
                    with zipfile.ZipFile(path) as zi:
                        for e in zi.infolist():
                            if e.is_dir():
                                continue
                            rel = e.filename.split('/', 1)[1] if '/' in e.filename else e.filename
                            if pats and not any(p.match(rel) for p in pats):
                                continue
                            zo.writestr((b + '/' if multi else '') + rel, zi.read(e))
                            kept += 1
            if not kept:
                os.remove(out)
                die('No files matched your patterns.')
            log(f'Kept {kept} files')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    log(f'Saved {os.path.abspath(out)} ({fmt(os.path.getsize(out))})')
    tl.finish()


def cmd_copy(a):
    o, r, ub = parse(a.url)
    if not a.dest_token:
        die('Add --dest-token (or set DEST_TOKEN).')
    if a.files:
        die('Copy keeps full history, so it cannot filter files. Use the web page for a file-filtered copy.')
    tl = Timeline(['Connect to GitHub', 'Create new repository', 'Download with history', 'Upload to your account', 'Finished'])
    tl.go(0)
    me = json.load(api('/user', a.dest_token))['login']
    log(f'Destination account: {me}')
    info = repo_info(o, r, a.token)
    log(f'Source: {info["full_name"]} (about {fmt(info["size"]*1024)})')
    chosen = a.branch or a.all_branches or ub
    brs = pick(a, o, r, ub, info, []) if chosen else []
    if brs:
        brs.sort(key=lambda b: b != info['default_branch'])
        log('Branches: ' + ', '.join(brs))
    else:
        log('Branches: all (with tags)')
    tl.go(1)
    name = a.name or r
    made = json.load(api('/user/repos', a.dest_token, {'name': name, 'private': a.private, 'description': f'Copy of {o}/{r}'}))
    log(f'Created {made["full_name"]}')
    tmp = tempfile.mkdtemp(prefix='cloner-')
    try:
        bare = os.path.join(tmp, 'repo.git')
        tl.go(2)
        git(['clone', '--bare', '--progress', f'https://github.com/{o}/{r}.git', bare], a.token)
        tl.go(3)
        url = f'https://github.com/{me}/{made["name"]}.git'
        if brs:
            git(['-C', bare, 'push', '--progress', url] + [f'refs/heads/{b}:refs/heads/{b}' for b in brs], a.dest_token)
            if a.tags:
                git(['-C', bare, 'push', '--progress', '--tags', url], a.dest_token)
            api(f'/repos/{me}/{made["name"]}', a.dest_token, {'default_branch': brs[0]}, method='PATCH')
        else:
            git(['-C', bare, 'push', '--progress', '--all', url], a.dest_token)
            git(['-C', bare, 'push', '--progress', '--tags', url], a.dest_token)
        log(f'Your copy: {made["html_url"]}')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    tl.finish()


def main():
    ap = argparse.ArgumentParser(description='Repo Cloner with a live timeline')
    sub = ap.add_subparsers(dest='cmd', required=True)
    for n, fn in (('clone', cmd_clone), ('zip', cmd_zip), ('copy', cmd_copy), ('branches', cmd_branches), ('tree', cmd_tree)):
        p = sub.add_parser(n)
        p.add_argument('url')
        p.add_argument('--token', default=os.environ.get('GITHUB_TOKEN'))
        p.set_defaults(fn=fn, all_branches=False, files=None, branch=None)
        if n != 'branches':
            p.add_argument('-b', '--branch', action='append')
        if n in ('clone', 'zip', 'copy'):
            p.add_argument('--all-branches', action='store_true')
        if n in ('clone', 'zip', 'tree', 'copy'):
            p.add_argument('-f', '--files', action='append')
        if n == 'clone':
            p.add_argument('--dir')
        if n == 'zip':
            p.add_argument('--out')
        if n == 'copy':
            p.add_argument('--dest-token', default=os.environ.get('DEST_TOKEN'))
            p.add_argument('--name')
            p.add_argument('--private', action='store_true')
            p.add_argument('--tags', action='store_true')
    a = ap.parse_args()
    try:
        a.fn(a)
    except KeyboardInterrupt:
        die('Cancelled.')


if __name__ == '__main__':
    main()
