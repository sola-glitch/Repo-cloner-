/* Welcome slides: four short animated cards you can swipe or tap through. */
(function(){
const T=window.Tutorials=window.Tutorials||{};
const $=s=>document.querySelector(s);
const HTML=`<div id="sl" class="ov" hidden><div class="card" role="dialog" aria-label="Welcome tutorial">
<button id="sx" class="x" aria-label="Close">×</button>
<div class="sview" id="sv"><div class="strack" id="st">
<section class="sd"><div class="art"><div class="f"><span class="ty">octocat/Hello-World</span></div><div class="ch"><i>Download files</i><i>Quick zip</i><i>Copy to account</i></div></div><h3>Start with a repository</h3><p>Paste a GitHub link or owner/repo, then pick a tab: download files, quick zip, or copy to your account.</p></section>
<section class="sd"><div class="art a2"><div class="cb"><s></s>main</div><div class="cb"><s></s>dev</div><div class="cb"><s></s>docs</div><div class="pt">docs/ and *.md</div></div><h3>Choose branches and files</h3><p>Tick one branch, several, or all. Add patterns like docs/ or *.md to take only the files you need.</p></section>
<section class="sd"><div class="art"><div class="f"><span class="dt">••••••••••</span></div><div class="lock">Optional for public repos</div></div><h3>Tokens for private repos</h3><p>Public repos need no token. For private repos, or to copy into your account, paste a GitHub token. It goes only to GitHub.</p></section>
<section class="sd"><div class="art a4"><ol><li>Connect to GitHub</li><li>Read repository</li><li>Download files</li><li>Finished</li></ol><div class="pb"><i></i></div></div><h3>Watch the timeline</h3><p>Every stage shows its time, and two bars show the current file and overall progress.</p></section>
</div></div>
<div class="ctl"><span id="sdots" class="dots"></span><span><button id="sback" class="tbtn alt">Back</button><button id="snext" class="tbtn">Next</button></span></div>
</div></div>`;
let built=false,n=0,x0=null,o,sd,dots;
function go(k){
  n=Math.max(0,Math.min(sd.length-1,k));$('#st').style.transform='translateX(-'+n*100+'%)';
  sd.forEach((s,j)=>s.classList.toggle('act',j===n));[...dots.children].forEach((x,j)=>x.className=j===n?'on':'');
  $('#sback').disabled=n===0;$('#snext').textContent=n===sd.length-1?'Done':'Next';
}
const close=()=>{o.hidden=true;sd.forEach(s=>s.classList.remove('act'))};
function build(){
  if(built)return;built=true;
  document.body.insertAdjacentHTML('beforeend',HTML);
  o=$('#sl');sd=[...o.querySelectorAll('.sd')];dots=$('#sdots');
  dots.innerHTML=sd.map(()=>'<i></i>').join('');
  $('#snext').onclick=()=>n===sd.length-1?close():go(n+1);
  $('#sback').onclick=()=>go(n-1);
  $('#sx').onclick=close;
  o.addEventListener('click',e=>{if(e.target===o)close()});
  $('#sv').addEventListener('pointerdown',e=>{x0=e.clientX});
  $('#sv').addEventListener('pointerup',e=>{if(x0===null)return;const dx=e.clientX-x0;x0=null;if(dx<-40)go(n+1);else if(dx>40)go(n-1)});
  addEventListener('keydown',e=>{if(o.hidden)return;if(e.key==='Escape')close();else if(e.key==='ArrowRight')go(n+1);else if(e.key==='ArrowLeft')go(n-1)});
}
T.slides={title:'Welcome slides',text:'Four short animated cards. Swipe or tap through them.',start(){build();o.hidden=false;go(0)}};
})();
