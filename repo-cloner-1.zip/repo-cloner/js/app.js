/* Repo Cloner: app logic (downloads, zips, copies, live timeline) */
const $=s=>document.querySelector(s);
const LABEL={files:'Download files',zip:'Download zip',copy:'Copy to my account'};
const STAGES={
  files:['Connect to GitHub','Read repository','Download files','Package zip','Finished'],
  zip:['Connect to GitHub','Download zip','Finished'],
  copy:['Connect to GitHub','Read repository','Create new repository','Copy files','Write commit','Finished']};
let mode='files',cur=-1,t0=0,lastBlob=null,lastName='';

const kb=n=>n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB';
const pad=n=>String(n).padStart(2,'0');
const clock=()=>{const d=new Date();return pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds())};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const bar=(id,f)=>{$(id).style.width=Math.max(0,Math.min(1,f))*100+'%'};

function log(m,err){
  if(!err&&!/^(Saved|Your copy)/.test(m))return;
  const s=$('#status');s.className='note'+(err?' err':'');
  s.innerHTML=esc(m).replace(/(https:\/\/\S+)/,'<a href="$1" target="_blank" rel="noopener">$1</a>');
}
function draw(){
  $('#stages').innerHTML=STAGES[mode].map((n,i)=>'<li id="s'+i+'">'+n+'<small></small></li>').join('');
}
function mark(i,cls){const li=$('#s'+i);if(!li)return;li.className=cls;if(cls==='done'||cls==='fail')li.querySelector('small').textContent=((Date.now()-t0)/1000).toFixed(1)+'s'}
function go(i){if(cur>=0)mark(cur,'done');cur=i;t0=Date.now();mark(i,'active');log(STAGES[mode][i])}
function finish(){mark(cur,'done');const last=STAGES[mode].length-1;cur=last;mark(last,'done');bar('#allBar',1);log('All done')}

function parse(s){
  s=s.trim().replace(/\.git$/,'');
  const m=s.match(/github\.com[\/:]([^\/]+)\/([^\/#?]+)(?:\/tree\/([^#?]+))?/)||s.match(/^([\w.-]+)\/([\w.-]+)$/);
  if(!m)throw new Error('Enter a GitHub URL or owner/repo.');
  return{owner:m[1],repo:m[2].replace(/\.git$/,''),branch:m[3]||''};
}
async function gh(path,token,opt={}){
  const r=await fetch(path.startsWith('http')?path:'https://api.github.com'+path,{...opt,headers:{Accept:'application/vnd.github+json',...(token?{Authorization:'Bearer '+token}:{}),...(opt.headers||{})}});
  if(!r.ok){let t='';try{t=(await r.json()).message}catch{}
    if(r.status===403||r.status===429)t+=' (rate limit? add a token)';
    if(r.status===404&&!token)t+=' (private repo? add a token)';
    throw new Error(r.status+' '+(t||r.statusText))}
  return r;
}
async function stream(r,total,onp){
  total=+r.headers.get('content-length')||total||0;
  const rd=r.body.getReader(),ch=[];let got=0;
  for(;;){const{done,value}=await rd.read();if(done)break;ch.push(value);got+=value.length;onp(got,total)}
  return new Blob(ch);
}
function save(blob,name){
  lastBlob=blob;lastName=name;
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.append(a);a.click();a.remove();
  log('Saved '+name+' ('+kb(blob.size)+')');$('#again').hidden=false;
}
const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const ticked=new Set();let flist=[];
function rx(p){
  p=p.trim().replace(/^\.?\//,'');if(!p)return null;
  const anywhere=!p.includes('/');
  if(p.endsWith('/'))p+='**';
  let r='';
  for(let i=0;i<p.length;i++){const c=p[i];
    if(c==='*'&&p[i+1]==='*'){if(p[i+2]==='/'){r+='(?:.*/)?';i+=2}else{r+='.*';i++}}
    else if(c==='*')r+='[^/]*';
    else if(c==='?')r+='[^/]';
    else r+=c.replace(/[.+^${}()|[\]\\]/g,'\\$&');}
  return new RegExp('^'+(anywhere?'(?:.*/)?':'')+r+(/[*?]/.test(p)?'':'(?:/.*)?')+'$');
}
function chooser(){
  if($('#panel').hidden)return{pats:[],ticks:new Set()};
  return{pats:$('#pat').value.split(/[\n,]+/).map(rx).filter(Boolean),ticks:ticked};
}
const filt=(files,c)=>(!c.pats.length&&!c.ticks.size)?files:files.filter(f=>c.ticks.has(f.path)||c.pats.some(r=>r.test(f.path)));
function chosen(info,p){
  const v=$('#panel').hidden?[]:[...document.querySelectorAll('#brs input:checked')].map(i=>i.value);
  return v.length?v:[p.branch||info.default_branch];
}
async function repoInfo(p,src){
  const info=await (await gh('/repos/'+p.owner+'/'+p.repo,src)).json();
  log('Found '+info.full_name+' (default branch '+info.default_branch+')');
  return info;
}
async function readTrees(p,src,info){
  go(1);
  const c=chooser(),sets=[];
  for(const b of chosen(info,p)){
    const t=await (await gh('/repos/'+p.owner+'/'+p.repo+'/git/trees/'+encodeURIComponent(b)+'?recursive=1',src)).json();
    if(t.truncated)log(b+': the file list is too large and was cut short by GitHub',true);
    const all=t.tree.filter(x=>x.type==='blob');
    const sub=t.tree.filter(x=>x.type==='commit').length;
    if(sub)log(b+': skipped '+sub+' submodule(s)');
    const files=filt(all,c);
    log(b+': '+files.length+' of '+all.length+' files, '+kb(files.reduce((a,f)=>a+(f.size||0),0)));
    if(files.length)sets.push({branch:b,files});else log('Nothing matched on '+b,true);
  }
  if(!sets.length)throw new Error('Nothing matched your branch and file choices.');
  return sets;
}
async function getFile(p,src,branch,f){
  const url=src?'https://api.github.com/repos/'+p.owner+'/'+p.repo+'/git/blobs/'+f.sha
    :'https://raw.githubusercontent.com/'+p.owner+'/'+p.repo+'/'+branch.split('/').map(encodeURIComponent).join('/')+'/'+f.path.split('/').map(encodeURIComponent).join('/');
  const r=src?await gh(url,src,{headers:{Accept:'application/vnd.github.raw+json'}}):await fetch(url);
  if(!r.ok)throw new Error(r.status+' on '+f.path);
  $('#curName').textContent=f.path;
  return stream(r,f.size,(g,t)=>{bar('#fileBar',t?g/t:0);$('#curSize').textContent=kb(g)+(t?' / '+kb(t):'')});
}

async function doFiles(p,src){
  go(0);
  const info=await repoInfo(p,src);
  const sets=await readTrees(p,src,info);
  go(2);
  const zip=new JSZip(),multi=sets.length>1;
  const total=sets.reduce((a,x)=>a+x.files.length,0);let n=0;
  for(const x of sets)for(const f of x.files){
    const b=await getFile(p,src,x.branch,f);
    zip.file(multi?x.branch+'/'+f.path:f.path,b);n++;
    bar('#allBar',n/total*0.8);$('#allTxt').textContent=n+' of '+total+' files';
    log('✓ '+(multi?x.branch+': ':'')+f.path+' ('+kb(b.size)+')');
  }
  go(3);
  const out=await zip.generateAsync({type:'blob'},m=>{bar('#allBar',0.8+m.percent/500);bar('#fileBar',m.percent/100);$('#curName').textContent='Packaging';$('#curSize').textContent=Math.round(m.percent)+'%'});
  save(out,p.repo+(multi?'-branches':'-'+sets[0].branch.replace(/\//g,'-'))+'.zip');finish();
}
async function doZip(p,src){
  go(0);
  const info=await (await gh('/repos/'+p.owner+'/'+p.repo,src)).json();
  const branch=p.branch||info.default_branch;
  go(1);$('#curName').textContent=p.repo+'.zip';
  const name=p.repo+'-'+branch.replace(/\//g,'-')+'.zip';
  try{
    const r=await gh('/repos/'+p.owner+'/'+p.repo+'/zipball/'+encodeURIComponent(branch),src);
    const b=await stream(r,info.size*1024,(g,t)=>{bar('#fileBar',t?g/t:0);bar('#allBar',t?g/t:0);$('#curSize').textContent=kb(g)+(t?' / '+kb(t):'')});
    save(b,name);
  }catch(e){
    log('Direct download blocked ('+e.message+'). Opening GitHub’s zip link instead.',true);
    if(src)throw new Error('Private repos need the Download files tab or the Termux script.');
    location.href='https://api.github.com/repos/'+p.owner+'/'+p.repo+'/zipball/'+encodeURIComponent(branch);
  }
  finish();
}
const b64=buf=>{let s='';const u=new Uint8Array(buf);for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
const J={'Content-Type':'application/json'};
async function doCopy(p,src){
  const dt=$('#dtoken').value.trim();
  if(!dt)throw new Error('Add a destination token.');
  go(0);
  const me=await (await gh('/user',dt)).json();
  log('Destination account: '+me.login);
  const info=await repoInfo(p,src);
  const sets=await readTrees(p,src,info);
  go(2);
  const name=$('#dname').value.trim()||p.repo;
  const made=await (await gh('/user/repos',dt,{method:'POST',headers:J,body:JSON.stringify({name,private:$('#priv').checked,auto_init:true,description:'Copy of '+p.owner+'/'+p.repo})})).json();
  const dest='/repos/'+me.login+'/'+made.name,db=made.default_branch;
  log('Created '+made.full_name);
  go(3);
  const total=sets.reduce((a,x)=>a+x.files.length,0),cache={},trees=[];let n=0;
  for(const x of sets){
    const entries=[];
    for(const f of x.files){
      let sha=cache[f.sha];
      if(!sha){
        const b=await getFile(p,src,x.branch,f);
        sha=(await (await gh(dest+'/git/blobs',dt,{method:'POST',headers:J,body:JSON.stringify({content:b64(await b.arrayBuffer()),encoding:'base64'})})).json()).sha;
        cache[f.sha]=sha;log('✓ '+(sets.length>1?x.branch+': ':'')+f.path+' ('+kb(b.size)+')');
      }else log('✓ '+f.path+' (already uploaded)');
      entries.push({path:f.path,mode:f.mode,type:'blob',sha});n++;
      bar('#allBar',n/total*0.9);$('#allTxt').textContent=n+' of '+total+' files';
    }
    trees.push({branch:x.branch,entries});
  }
  go(4);
  let ref;for(let i=0;i<5;i++){try{ref=await (await gh(dest+'/git/ref/heads/'+db,dt)).json();break}catch(e){if(i===4)throw e;await sleep(1000)}}
  for(const t of trees){
    const tree=await (await gh(dest+'/git/trees',dt,{method:'POST',headers:J,body:JSON.stringify({tree:t.entries})})).json();
    const com=await (await gh(dest+'/git/commits',dt,{method:'POST',headers:J,body:JSON.stringify({message:'Copy of '+p.owner+'/'+p.repo+'@'+t.branch,tree:tree.sha,parents:[ref.object.sha]})})).json();
    if(t.branch===db)await gh(dest+'/git/refs/heads/'+db,dt,{method:'PATCH',headers:J,body:JSON.stringify({sha:com.sha,force:true})});
    else await gh(dest+'/git/refs',dt,{method:'POST',headers:J,body:JSON.stringify({ref:'refs/heads/'+t.branch,sha:com.sha})});
    log('Wrote branch '+t.branch);
  }
  const names=trees.map(t=>t.branch),want=names.includes(info.default_branch)?info.default_branch:names[0];
  if(want!==db){
    await gh(dest,dt,{method:'PATCH',headers:J,body:JSON.stringify({default_branch:want})});
    if(!names.includes(db))await gh(dest+'/git/refs/heads/'+db,dt,{method:'DELETE'});
  }
  log('Your copy: '+made.html_url);finish();
}

function upd(n){$('#selInfo').textContent=(n>300?'Showing 300 of '+n+' files. Use the filter or patterns to narrow down. ':n+' files listed. ')+ticked.size+' ticked.'}
function drawFiles(){
  const q=$('#flt').value.toLowerCase(),rows=flist.filter(f=>f.toLowerCase().includes(q));
  $('#files').innerHTML=rows.slice(0,300).map(f=>'<label class="it"><input type="checkbox" value="'+esc(f)+'"'+(ticked.has(f)?' checked':'')+'> '+esc(f)+'</label>').join('')||'<div class="note">No files match.</div>';
  upd(rows.length);
}
async function load(){
  const btn=$('#load');btn.disabled=true;$('#pickMsg').textContent='Loading…';
  try{
    const p=parse($('#repo').value),src=$('#stoken').value.trim(),base='/repos/'+p.owner+'/'+p.repo;
    const info=await (await gh(base,src)).json();
    const br=[];
    for(let pg=1;pg<=5;pg++){const a=await (await gh(base+'/branches?per_page=100&page='+pg,src)).json();br.push(...a.map(x=>x.name));if(a.length<100)break}
    const pre=p.branch||info.default_branch;
    $('#brs').innerHTML=br.map(n=>'<label class="it"><input type="checkbox" value="'+esc(n)+'"'+(n===pre?' checked':'')+'> '+esc(n)+'</label>').join('');
    const t=await (await gh(base+'/git/trees/'+encodeURIComponent(pre)+'?recursive=1',src)).json();
    flist=t.tree.filter(x=>x.type==='blob').map(x=>x.path);
    ticked.clear();$('#flt').value='';drawFiles();
    $('#prevOf').textContent='(listed from '+pre+')';$('#allBr').textContent='Select all';
    $('#panel').hidden=false;$('#pickMsg').textContent='';
  }catch(e){$('#pickMsg').textContent='Could not load: '+e.message}
  btn.disabled=false;
}
$('#load').onclick=load;
$('#flt').oninput=drawFiles;
$('#files').onchange=e=>{const i=e.target;i.checked?ticked.add(i.value):ticked.delete(i.value);$('#selInfo').textContent=$('#selInfo').textContent.replace(/\d+ ticked\./,ticked.size+' ticked.')};
$('#allBr').onclick=()=>{const bs=[...document.querySelectorAll('#brs input')],all=bs.every(x=>x.checked);bs.forEach(x=>x.checked=!all);$('#allBr').textContent=all?'Select all':'Clear all'};
$('#repo').addEventListener('input',()=>{$('#panel').hidden=true;$('#pickMsg').textContent=''});

document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{
  mode=b.dataset.m;
  document.querySelectorAll('.tabs button').forEach(x=>x.setAttribute('aria-selected',x===b));
  $('#copyOnly').hidden=mode!=='copy';$('#pick').hidden=mode==='zip';$('#go').textContent=LABEL[mode];
});
$('#again').onclick=()=>lastBlob&&save(lastBlob,lastName);
$('#go').onclick=async()=>{
  $('#tl').hidden=false;$('#status').textContent='';$('#again').hidden=true;
  cur=-1;draw();['#fileBar','#allBar'].forEach(i=>bar(i,0));
  $('#curName').textContent='Current file';$('#curSize').textContent='';$('#allTxt').textContent='';
  $('#go').disabled=true;
  try{
    const p=parse($('#repo').value),src=$('#stoken').value.trim();
    await({files:doFiles,zip:doZip,copy:doCopy}[mode])(p,src);
  }catch(e){if(cur>=0)mark(cur,'fail');log('Stopped: '+e.message,true)}
  $('#go').disabled=false;
};

/* ---- Hooks used by the tutorials (js/tutorial-*.js) ---- */
window.RC={
  timer:null,samplePanelOn:false,sampleTimelineOn:false,
  busy(){return $('#go').disabled},
  tab(){return mode},
  setTab(m){document.querySelector('.tabs button[data-m="'+m+'"]').click()},
  samplePanel(){
    if(!$('#panel').hidden)return;
    this.samplePanelOn=true;
    $('#brs').innerHTML=['main','dev','docs'].map((n,k)=>'<label class="it"><input type="checkbox" value="'+n+'"'+(k===0?' checked':'')+'> '+n+'</label>').join('');
    flist=['README.md','docs/intro.md','src/index.js','src/util.js','package.json'];ticked.clear();$('#flt').value='';drawFiles();
    $('#prevOf').textContent='(example)';$('#panel').hidden=false;
  },
  sampleTimeline(){
    if($('#tl').hidden){
      this.sampleTimelineOn=true;$('#tl').hidden=false;cur=-1;draw();mark(0,'done');mark(1,'done');mark(2,'active');
      $('#curName').textContent='src/index.js';$('#curSize').textContent='12 KB / 20 KB';$('#allTxt').textContent='4 of 10 files';
    }
    if(!this.sampleTimelineOn)return;
    let v=.1;bar('#allBar',v);bar('#fileBar',.5);
    this.timer=setInterval(()=>{v=v>=.9?.1:v+.1;bar('#allBar',v);bar('#fileBar',(v*1.7)%1)},700);
  },
  pauseSample(){clearInterval(this.timer)},
  clearSamples(){
    clearInterval(this.timer);
    if(this.samplePanelOn){$('#panel').hidden=true;$('#brs').innerHTML='';flist=[];ticked.clear();drawFiles();this.samplePanelOn=false}
    if(this.sampleTimelineOn){$('#tl').hidden=true;['#fileBar','#allBar'].forEach(b=>bar(b,0));$('#curName').textContent='Current file';$('#curSize').textContent='';$('#allTxt').textContent='';this.sampleTimelineOn=false}
  }
};
