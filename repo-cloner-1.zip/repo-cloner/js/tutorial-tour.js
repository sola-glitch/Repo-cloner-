/* Spotlight tour: highlights each part of the page with a short tip. */
(function(){
const T=window.Tutorials=window.Tutorials||{};
const $=s=>document.querySelector(s);
const HTML=`<div id="tour" hidden><div id="spot"></div>
<div id="tip" role="dialog" aria-live="polite"><b id="tt"></b><p id="tx"></p>
<div class="trow"><span id="tn"></span><span><button id="tskip" class="tbtn alt">Skip</button><button id="tback" class="tbtn alt">Back</button><button id="tnext" class="tbtn">Next</button></span></div></div></div>`;
let built=false,i=0,m0='files',tour,spot,tip;
const S=[
 {e:'#repo',t:'Paste a repository',x:'Paste a GitHub link or owner/repo, for example octocat/Hello-World.',p:()=>RC.setTab('files')},
 {e:'.tabs',t:'Pick what to do',x:'Download files lets you choose what to take. Quick zip grabs the whole repo fast. Copy to account makes your own copy.'},
 {e:'#load',t:'Choose what to take',x:'Optional. Tap this to pick branches and files. Skip it to get the default branch and everything.'},
 {e:'#brs',t:'Branches',x:'Tick one branch, several, or use Select all.',p:()=>RC.samplePanel()},
 {e:'#pat',t:'File patterns',x:'One per line. Try src/**/*.js, docs/ for a whole folder, or README.md.'},
 {e:'#files',t:'Or tick files',x:'Tick files from the list. Patterns and ticks add together. Leave both empty to take everything.'},
 {e:'#stoken',t:'Private repos',x:'Public repos need no token. For private repos, paste a GitHub token here. It goes only to GitHub.'},
 {e:'#copyOnly',t:'Copying needs a destination',x:'To copy into your account, add a destination token and a name for the new repo.',p:()=>RC.setTab('copy')},
 {e:'#go',t:'Start',x:'Tap the button to begin.',p:()=>RC.setTab('files')},
 {e:'#tl',t:'The timeline',x:'Each stage shows its time. The top bar is the current file, the bottom bar is overall progress.',p:()=>{RC.setTab('files');RC.sampleTimeline()}}
];
function build(){
  if(built)return;built=true;
  document.body.insertAdjacentHTML('beforeend',HTML);
  tour=$('#tour');spot=$('#spot');tip=$('#tip');
  $('#tnext').onclick=()=>i<S.length-1?show(i+1):end();
  $('#tback').onclick=()=>show(i-1);
  $('#tskip').onclick=end;
  addEventListener('keydown',e=>{if(e.key==='Escape'&&!tour.hidden)end()});
  addEventListener('resize',()=>{if(!tour.hidden)show(i)});
}
function show(k){
  i=k;RC.pauseSample();const s=S[k];s.p&&s.p();
  const el=document.querySelector(s.e);el.scrollIntoView({block:'center'});
  requestAnimationFrame(()=>{
    const r=el.getBoundingClientRect(),pd=6;
    Object.assign(spot.style,{top:r.top-pd+'px',left:r.left-pd+'px',width:r.width+2*pd+'px',height:r.height+2*pd+'px'});
    $('#tt').textContent=s.t;$('#tx').textContent=s.x;$('#tn').textContent=(k+1)+' of '+S.length;
    $('#tback').disabled=k===0;$('#tnext').textContent=k===S.length-1?'Done':'Next';
    const h=tip.offsetHeight;let top=r.bottom+pd+12;
    if(top+h>innerHeight-8)top=r.top-pd-12-h;
    if(top<8)top=innerHeight-h-8;
    tip.style.top=top+'px';
  });
}
function end(){RC.pauseSample();tour.hidden=true;RC.clearSamples();RC.setTab(m0);scrollTo(0,0)}
T.tour={title:'Spotlight tour',text:'Highlights each part of the page, one tip at a time.',start(){if(RC.busy())return;build();m0=RC.tab();tour.hidden=false;show(0)}};
})();
