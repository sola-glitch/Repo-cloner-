/* Tutorial chooser: the Help button asks which tutorial style to play. */
(function(){
const $=s=>document.querySelector(s);
const ORDER=['tour','demo','slides'];
let box=null;
function build(){
  document.body.insertAdjacentHTML('beforeend','<div id="tchoose" class="ov" hidden><div class="card" role="dialog" aria-label="Choose a tutorial"><button id="tcx" class="x" aria-label="Close">×</button><h2>How do you want to learn?</h2><p class="lead">Pick a style. You can come back any time with Help.</p><div id="topts"></div></div></div>');
  box=$('#tchoose');
  const T=window.Tutorials||{};
  $('#topts').innerHTML=ORDER.filter(k=>T[k]).map(k=>'<button class="opt" data-k="'+k+'"><b>'+T[k].title+'</b><span>'+T[k].text+'</span></button>').join('');
  $('#topts').onclick=e=>{const b=e.target.closest('.opt');if(!b)return;box.hidden=true;T[b.dataset.k].start()};
  $('#tcx').onclick=()=>{box.hidden=true};
  box.addEventListener('click',e=>{if(e.target===box)box.hidden=true});
  addEventListener('keydown',e=>{if(e.key==='Escape'&&!box.hidden)box.hidden=true});
}
$('#help').onclick=()=>{if(RC.busy())return;if(!box)build();box.hidden=false};
})();
