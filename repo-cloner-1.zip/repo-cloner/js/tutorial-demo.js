/* Auto-playing demo: a pretend repo is downloaded while captions explain each step. */
(function(){
const T=window.Tutorials=window.Tutorials||{};
const $=s=>document.querySelector(s);
const HTML=`<div id="demo" class="ov" hidden><div class="card" role="dialog" aria-label="Animated tutorial">
<button id="dclose" class="x" aria-label="Close">×</button>
<div class="mlab" style="margin-top:0">Repository</div><div class="mf"><span id="m1"></span><u></u></div>
<div class="mtabs"><i>Download files</i><i>Quick zip</i><i>Copy to account</i></div>
<div class="mgrp" id="g2"><div class="mlab">Branches</div><div class="mbr"><b id="b1"><s></s>main</b><b id="b2"><s></s>dev</b><b><s></s>docs</b></div>
<div class="mlab">File patterns</div><div class="mf"><span id="m3"></span></div></div>
<div class="mgrp" id="g3"><div class="mlab">Token (optional)</div><div class="mf"><span id="m5"></span></div></div>
<div class="mgrp" id="g4"><ol class="mtl"><li>Connect to GitHub</li><li>Read repository</li><li>Download files</li><li>Package zip</li></ol><div class="pb"><i id="m4"></i></div><div id="mdone"></div></div>
<p id="dcap"></p>
<div class="ctl"><span id="dd" class="dots"><i></i><i></i><i></i><i></i></span><button id="drep" class="tbtn">Replay</button></div>
</div></div>`;
let built=false,pid=0,d;
const w=ms=>new Promise(r=>setTimeout(r,ms));
async function type(el,txt,id,sp,mask){for(let k=1;k<=txt.length;k++){if(id!==pid)return false;el.textContent=mask?'•'.repeat(k):txt.slice(0,k);await w(sp||60)}return true}
async function play(){
  const id=++pid,ok=()=>id===pid;
  ['#m1','#m3','#m5','#mdone'].forEach(s=>$(s).textContent='');
  d.querySelectorAll('.mgrp').forEach(g=>g.classList.remove('on'));
  d.querySelectorAll('.mtabs i,.mbr b,.mtl li').forEach(x=>x.className='');
  $('#m4').style.width='0';
  const cap=(n,t)=>{$('#dcap').textContent=t;[...$('#dd').children].forEach((x,k)=>x.className=k<=n?'on':'')};
  cap(0,'1. Paste a GitHub link or owner/repo, then pick a tab.');
  if(!await type($('#m1'),'octocat/Hello-World',id))return;
  await w(500);if(!ok())return;
  d.querySelector('.mtabs i').classList.add('on');await w(1800);if(!ok())return;
  cap(1,'2. Optional: choose branches and files. Tick several, or type patterns like docs/ or *.md.');
  $('#g2').classList.add('on');await w(900);if(!ok())return;
  $('#b1').className='on';await w(600);if(!ok())return;
  $('#b2').className='on';await w(600);if(!ok())return;
  if(!await type($('#m3'),'docs/  *.md',id))return;
  await w(1800);if(!ok())return;
  cap(2,'3. Private repo? Paste a GitHub token. Public repos need none. It goes only to GitHub.');
  $('#g3').classList.add('on');await w(600);if(!ok())return;
  if(!await type($('#m5'),'ghp_xxxxxxxxxxxx',id,70,true))return;
  await w(1800);if(!ok())return;
  cap(3,'4. Tap the button and watch the timeline. Each stage shows its time, and the bar shows progress.');
  $('#g4').classList.add('on');
  const L=[...d.querySelectorAll('.mtl li')];
  for(let k=0;k<L.length;k++){
    if(!ok())return;L[k].className='act';$('#m4').style.width=(k+.5)/L.length*100+'%';await w(1100);
    if(!ok())return;L[k].className='done';$('#m4').style.width=(k+1)/L.length*100+'%';await w(300);
  }
  if(ok())$('#mdone').textContent='Saved octocat-Hello-World.zip';
}
const close=()=>{pid++;d.hidden=true};
function build(){
  if(built)return;built=true;
  document.body.insertAdjacentHTML('beforeend',HTML);
  d=$('#demo');
  $('#drep').onclick=play;
  $('#dclose').onclick=close;
  d.addEventListener('click',e=>{if(e.target===d)close()});
  addEventListener('keydown',e=>{if(e.key==='Escape'&&!d.hidden)close()});
}
T.demo={title:'Auto-playing demo',text:'Watch a pretend repo being downloaded, with captions.',start(){build();d.hidden=false;play()}};
})();
